angular.module('app.controllers', [])
     
.controller('menuCtrl', ['$scope', '$stateParams', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams) {


}])
   
.controller('loginCtrl',  // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $state, $http, $ionicPopup, $ionicLoading, $ionicPlatform,$ionicSideMenuDelegate,$stateParams,$ionicPopover) {
/* console.log(localStorage['auth']);
                        if(localStorage['auth']=="true"){
                        console.log('login true hai');
                        $state.go('myDashboard');
                        }
                        console.log(localStorage['auth']);
                         $ionicSideMenuDelegate.canDragContent(false);*/
$scope.login = function () {
                        $ionicLoading.show({
                             template: 'Redirecting...'
                        });
                            $http({
                                  method: 'POST',
                                  url: 'http://europa.promaticstechnologies.com/million/webservicelogin',
                                  data: {
                                    'email': $scope.user.email,
                                    'password': $scope.user.password
                                  },
                                  headers: {
                                    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
                                  }
                            }).success(function (data, status, header, config, message) {
                                 $ionicLoading.hide();
                                    if (data.response) {

                                                  
                                                    localStorage.setItem('auth', "true");
                                                    localStorage.setItem('rEmail', $scope.user.email);
                                                    console.log('requesterid' + localStorage ['rEmail']);
                                                    logsuc();
                                                  //localStorage.setItem('status', data.result.status);
                                            } else {
                                                   logfail();
                                                    }
                                }).error(function (data, status, header, config, message) {
                                                   $ionicLoading.hide();
                                                   });
             }

          logsuc = function () {
                                  var alertPopup = $ionicPopup.alert({
                                      title: 'Alert',
                                      template: 'Login Successfully'
                                  });
                                  alertPopup.then(function (res) {
                                        console.log('Login Successfully');
                                        $state.go('tabsController.millionOpportunities');

                                  });
                                  console.log('Login successfull');
                                  
                      }
          logfail = function () {
                                  var alertPopup = $ionicPopup.alert({
                                      title: 'Alert',
                                      template: 'Either Email or Password is incorrect!'
                                  });
                                  alertPopup.then(function (res) {
                                  //	$state.reload('login');
                                          console.log(res);
                                          console.log('User not login');
                                     });
            };
})
 
.controller('signupCtrl',  // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $state, $http, $ionicPopup, $ionicLoading, $ionicPlatform,$ionicSideMenuDelegate,$stateParams,$ionicPopover) {

 

              $scope.signup=function(){
		              	$ionicLoading.show({
		                                       template: 'Please Wait...'
		                                    });
		              					$http({
                                            method: 'POST',
                                            url: 'http://europa.promaticstechnologies.com/million/webservicesign_up', 
                                            data: 
                                            {  
                                               'firstname':$scope.firstName,
                                                'lastname':$scope.lastName,
                                                'email':$scope.email,
                                                'password':$scope.password,
                                                'username':$scope.userName,
                                                
                                               
                                               
                                             }, 
                                            headers: 
                                            {
                                              'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
                                            }
                                              }).success(function(data, status, header, config, message) {

                                          $ionicLoading.hide();
                                          if(data.response){
                                            regsuc();
                                            $state.go("login");
                                          }else{
                                            regfail(); 
                                          }
                                  }).error(function(data, status, header, config, message) {
                                    $ionicLoading.hide();
                                    regfail();
                                    });
                   }
                    regsuc = function() {
                            var alertPopup = $ionicPopup.alert({
                            title: 'Congratulations !',
                            template: 'Registration Completed successfully! '
                            });
                            alertPopup.then(function(res) {
                            console.log('User Registered');
                            });
                    };
                  regfail = function() {
                           var alertPopup = $ionicPopup.alert({
                           title: 'Alert',
                           template: ' Email Address is Already Registered! '
                           });
                           alertPopup.then(function(res) {
                            $state.reload('signup');
                           console.log('User Not Registered');
                           });
            };
        


})

   
.controller('manageAdsCtrl', ['$scope', '$stateParams', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams) {


}])
   
.controller('detailsCtrl',  // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $state, $http, $ionicPopup, $ionicLoading, $cordovaFileTransfer,$ionicPopover,$cordovaDevice, $ionicPlatform,$ionicSideMenuDelegate,$stateParams,$cordovaSocialSharing){
        $ionicSideMenuDelegate.canDragContent(false);  
        $scope.$on('$ionicView.beforeEnter', function(event, viewData) {
    
                                console.debug('[StoryController] $ionicView.beforeEnter');


                                viewData.enableBack = true;
                                console.log($stateParams);
                                console.log($stateParams.id);
                                var id =$stateParams.id;
                                console.log(id);
                                $ionicLoading.show({
                                   template: 'Please Wait...'
                                });
                                $http({
                                    method: 'post',
                                    url: 'http://europa.promaticstechnologies.com/million//webservicead_details',
                                    data:{
                                        'id':id,
                                        

                                    },
                                    headers: {
                                    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
                                    }
                                }).success(function (data, status, header, config, message) {
                                $ionicLoading.hide();
                                if (data.response) {
                                     $scope.detailsdata=angular.fromJson(data.result);
                                      $scope.timedata=data.c_time;
                                }
                                //LoadingSpinner.hide('pageLoading');
                                }).error(function (data, status, header, config, message) {
                                   $ionicLoading.hide();

                                });

                            $scope.shareAnywhere = function(dis,title,image) {
                           var discription=dis;
                           var title=title;
                           var image=image;
                           var c_image="http://europa.promaticstechnologies.com/million/uploads/"+image.replace('[','').replace('"','').replace('"','').replace(']','');
                          
                         //  var sentence="Audition Name: "+name+", "+"Starting: "+str+", "+"Ending: "+end+", "+"Descripton: "+discription+", "+"Location: "+location;
                           console.log(discription);
                           console.log(title);
                           console.log(image);
                           console.log('co'+c_image);
                         //  console.log(sentence);
                          $cordovaSocialSharing.share(discription,title,c_image,"http://europa.promaticstechnologies.com/million/");
                }     
});
})
   
.controller('filterimageCtrl',// The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $state, $http, $ionicPopup, $ionicLoading, $cordovaFileTransfer,$ionicPopover,$cordovaDevice, $ionicPlatform,$ionicSideMenuDelegate,$stateParams,$cordovaSocialSharing){
        $ionicSideMenuDelegate.canDragContent(false);  
        $scope.$on('$ionicView.beforeEnter', function(event, viewData) {
    
                                console.debug('[StoryController] $ionicView.beforeEnter');


                               
                                $ionicLoading.show({
                                   template: 'Please Wait...'
                                });
                                $http({
                                    method: 'post',
                                    url: 'http://europa.promaticstechnologies.com/million/webservicecategory',
                                    data:{
                                        'category':localStorage['filter'],
                                    },
                                    headers: {
                                    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
                                    }
                                }).success(function (data, status, header, config, message) {
                                $ionicLoading.hide();
                                if (data.response) {
                                     $scope.detailsdata=angular.fromJson(data.result);
                                      $scope.titledata=data.category;
                                }
                                //LoadingSpinner.hide('pageLoading');
                                }).error(function (data, status, header, config, message) {
                                   $ionicLoading.hide();

                                });

                            $scope.shareAnywhere = function(dis,title,image) {
                           var discription=dis;
                           var title=title;
                           var image=image;
                           var c_image="http://europa.promaticstechnologies.com/million/uploads/"+image.replace('[','').replace('"','').replace('"','').replace(']','');
                          
                         //  var sentence="Audition Name: "+name+", "+"Starting: "+str+", "+"Ending: "+end+", "+"Descripton: "+discription+", "+"Location: "+location;
                           console.log(discription);
                           console.log(title);
                           console.log(image);
                           console.log('co'+c_image);
                         //  console.log(sentence);
                          $cordovaSocialSharing.share(discription,title,c_image,"http://europa.promaticstechnologies.com/million/");
                }     
});
})
   
.controller('favouriteCtrl', ['$scope', '$stateParams', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams) {


}])
.controller('postAddCtrl2', 
function ($scope, $state, $http, $ionicPopup, $ionicLoading, $ionicPlatform, $ionicSideMenuDelegate, $stateParams, $ionicPopover,$cordovaCamera,$cordovaImagePicker) {
$scope.post=function(){


$ionicLoading.show({
                                           template: 'Please Wait...'
                                        });
                            $http({
                                           method: 'POST',
                                            url: 'http://europa.promaticstechnologies.com/million/webservicepost_ad', 
                                            data: 
                                            {  
                                               'category':localStorage['category'],
                                               'sub_category':localStorage['subcategory'],
                                               'postal_code':localStorage['pincode'],
                                               'seller_type':localStorage['radio'],
                                               'add_title':localStorage['title'],
                                               'short_description':localStorage['description'],
                                               'plate_number':localStorage['licence'],
                                               'mileage':localStorage['mileage'],
                                               'price':localStorage['price'],
                                               'email_me':localStorage ['rEmail'],
                                          
                                          'web_link':$scope.youtubelink,
                                          'description':$scope.description2,
                                          'web_check':$scope.websitelink,
                                       'urgent':$scope.urgent,
                                       'featured':$scope.featured,
                                       'spolight':$scope.spotlight,
                                       'call_me':$scope.contactno,
                                       'id': '',
                                       'modal':'' ,
                                       'color':'' ,
                                       'vmake':'' ,
                                       'v_body_type': '' ,
                                       'v_purchase_year': '',
                                       'fuel_type': '',
                                       'transmission': '',
                                       'engine_size':'' ,
                                       'ad_total': '',
                                       'image': '',
                                       'user_id': '',
                                       'ad_id': '',
                                       'payment_status': '',
                                       'likes': '',
                                       'created_at': '',
                                       'update_at': '',



                                             
                                               
                                               
                                             }, 
                                            headers: 
                                            {
                                              'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
                                            }
                                              }).success(function(data, status, header, config, message) {

                                          $ionicLoading.hide();
                                          if(data.response){
                                            regsuc();
                                            $state.go("tabsController.postAdd");
                                          }else{
                                            regfail(); 
                                          }
                                  }).error(function(data, status, header, config, message) {
                                    $ionicLoading.hide();
                                    regfail();
                                    });
                   }
                    regsuc = function() {
                            var alertPopup = $ionicPopup.alert({
                            title: 'Congratulations !',
                            template: 'post successfully uploaded! '
                            });
                            alertPopup.then(function(res) {
                           // console.log('User Registered');
                            });
                    };
                  regfail = function() {
                           var alertPopup = $ionicPopup.alert({
                           title: 'Alert',
                           template: ' post failed! '
                           });
                           alertPopup.then(function(res) {
                            //$state.reload('signup');
                          // console.log('User Not Registered');
                           });
            };


  $scope.takePicture = function (options) {
  
      var options = {
         quality : 75,
         targetWidth: 200,
         targetHeight: 200,
         sourceType: 1
      };

     $cordovaCamera.getPicture(options).then(function(imageData) {
         $scope.picture = imageData;
      }, function(err) {
         console.log(err);
      });
    
   };
    $scope.getPicture = function (options) {
  
      var options = {
           maximumImagesCount: 10,
           width: 800,
           height: 800,
           quality: 80
     };

     /*Camera.getPicture(options).then(function(imageData) {
         $scope.picture = imageData;;
      }, function(err) {
         console.log(err);
      });
   };  
})*/

  };
  $scope.pickimages=function(){
    $scope.collection = {
        selectedImage : ''
    };
console.log('Inside Pick Images');
$scope.items=[];
 var options = {
   maximumImagesCount: 5,
   width: 800,
   height: 800,
   quality: 80
  };

  $cordovaImagePicker.getPictures(options)
    .then(function (results) {
      for (var i = 0; i < results.length; i++) {
              $scope.collection.selectedImage = results[i];
              
            // uploadPhoto(results[i]);
            console.log('Image URI: ' + results[i]);
      }
     
    }, function(error) {
      // error getting photos
    })
  }

   })
.controller('postAddCtrl', 
function ($scope, $state, $http, $ionicPopup, $ionicLoading, $ionicPlatform, $ionicSideMenuDelegate, $stateParams, $ionicPopover,$cordovaCamera,$cordovaImagePicker)
{

 $scope.next = function(){
   localStorage.setItem('category',$scope.category);
   localStorage.setItem('subcategory',$scope.subcategory);
   localStorage.setItem('pincode',$scope.pincode);
   localStorage.setItem('radio',$scope.radio);
   localStorage.setItem('title',$scope.title);
   localStorage.setItem('description',$scope.description);
    localStorage.setItem('licence',$scope.licence);
    localStorage.setItem('mileage',$scope.mileage);
    

console.log('licence'+$scope.licence);
  console.log('category'+localStorage['category']);
   console.log('subcategory'+localStorage['subcategory']);
   console.log('pincode'+localStorage['pincode']);
   console.log('radio'+localStorage['radio']);
   console.log('Title'+localStorage['title']);
    console.log('description'+localStorage['description']);
    console.log('licence'+localStorage['licence']);
console.log('mileage'+localStorage['mileage']);
console.log('price'+localStorage['price']);
  


    $state.go("tabsController.postAdd2");
 }
  


 })



.controller('settingCtrl', ['$scope', '$state', '$ionicHistory', function($scope, $ionicHistory, $state, $http, $ionicPopup, $ionicLoading, $cordovaFileTransfer,$cordovaDevice, $ionicPlatform,$ionicSideMenuDelegate,$stateParams,$ionicPopover) {
  $scope.$on('$ionicView.beforeEnter', function(event, viewData) {

               $scope.email=localStorage['rEmail'];
               console.log($scope.email);
               viewData.enableBack = true;
               viewData.hideMenu = true;
               });
                $scope.logOut = function(){
                	$scope.email=localStorage['rEmail'];
               console.log($scope.email);

                    localStorage.clear(); 
                    $ionicHistory.clearCache();
                    $ionicHistory.clearHistory();
                     $state.go("tabsController.millionOpportunities");
                };
}])

 
   
.controller('helpCtrl', ['$scope', '$stateParams', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams) {


}])
   
.controller('millionOpportunitiesCtrl',
function ($scope, $state, $http, $ionicPopup, $ionicLoading, $ionicPlatform,$stateParams,$ionicPopover) {
    $scope.$on('$ionicView.beforeEnter', function(event, viewData) {

                              console.debug('[StoryController] $ionicView.beforeEnter');
                              viewData.enableBack = true;



                  $http({
                                  method: 'post',
                                  url: 'http://europa.promaticstechnologies.com/million/webservicepost_details',
                                  data: {
                                    
                              },
                              headers: {
                               'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
                              }
                              }).success(function (data, status, header, config, message) {
                                 // $ionicLoading.hide();
                                  if (data.response) {
                                    console.log('response'+data.response);
                                    console.log('response'+JSON.stringify(data.result));
                                     
                                     $scope.details=angular.fromJson(data.result);
                                   }
                             // console.log('count'+localStorage['count']);
                              }).error(function (data, status, header, config, message) {
                                   // $ionicLoading.hide();
                              });
     });



$scope.postad1=function(){
 $state.go("tabsController.postAdd");
}
$scope.filter=function(val){

   localStorage.setItem('filter',val);
   console.log('title'+localStorage['filter']);
 $state.go("filterimage");
}
})


   
.controller('aboutUsCtrl',
  function ($scope, $state, $http, $ionicPopup, $ionicLoading, $ionicPlatform,$stateParams,$ionicPopover) {
                            
                

								$ionicLoading.show({
                                template: 'Please Wait...'
                                });
                                $http({
                                    method: 'post',
                                    url: 'http://europa.promaticstechnologies.com/million/webserviceabout_us',
                                    data:{
                                        

                                    },
                                headers: {
                                  'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
                                }
                                }).success(function (data, status, header, config, message) {
                                $ionicLoading.hide();
                                if (data.response) {
                                    $scope.details=angular.fromJson(data.result[0]);   
                                }
                                //LoadingSpinner.hide('pageLoading');
                                }).error(function (data, status, header, config, message) {
                                 $ionicLoading.hide();

                                });



})



   
.controller('howItWorkCtrl',  function ($scope, $state, $http, $ionicPopup, $ionicLoading, $ionicPlatform,$stateParams,$ionicPopover) {
                            
                            var viewdata;

                                
                                $http({
                                  method: 'POST',
                                  url: 'http://europa.promaticstechnologies.com/million/webservicehow_it_works',
                                  data:{
                                      

                                  },
                                 
                              }).then(function mySucces(response) {
      $scope.title = response.data;
      $scope.description=response.data;
    }, function myError(response) {
      $scope.title = response.statusText;
  });
})
                                //  console.log('data submitted');
                             //console.log('check'+viewdata);
                                  
                               // }
                                       //   invitesfail();
                                    
                                //LoadingSpinner.hide('pageLoading');
                            //    }).error(function (data, status, header, config, message) {
                           //     $ionicLoading.hide();

                               
.controller('contactUsCtrl', ['$scope', '$stateParams', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams) {


}])
   
.controller('profileCtrl', ['$scope', '$stateParams', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams) {


}])
   
.controller('pageCtrl', ['$scope', '$stateParams', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams) {


}])
.controller('howCtrl',  function ($scope, $state, $http, $ionicPopup, $ionicLoading, $ionicPlatform,$stateParams,$ionicPopover) {
                            
                

								$ionicLoading.show({
                                template: 'Please Wait...'
                                });
                                $http({
                                    method: 'post',
                                    url: 'http://europa.promaticstechnologies.com/million/webservicehow_it_works',
                                    data:{
                                        

                                    },
                                headers: {
                                  'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
                                }
                                }).success(function (data, status, header, config, message) {
                                $ionicLoading.hide();
                                if (data.response) {
                                    $scope.details=angular.fromJson(data.result[0]);   
                                }
                                //LoadingSpinner.hide('pageLoading');
                                }).error(function (data, status, header, config, message) {
                                 $ionicLoading.hide();

                                });



})
 


////////////////////////////////////////just checking code ctrl

//.controller('postAddCtrl', function($scope, $cordovaImagePicker, $ionicPlatform) {
 /* $scope.takePicture = function (options) {
  
      var options = {
         quality : 75,
         targetWidth: 200,
         targetHeight: 200,
         sourceType: 1
      };

      Camera.getPicture(options).then(function(imageData) {
         $scope.picture = imageData;;
      }, function(err) {
         console.log(err);
      });
    
   };
$scope.getPicture = function (options) {
  
      var options = {
       quality : 75,
         targetWidth: 200,
         targetHeight: 200,
         sourceType: 0

    
      };

     Camera.getPicture(options).then(function(imageData) {
         $scope.picture = imageData;;
      }, function(error) {
      // error getting photos
    });


};
})*/
